# Kafka Consumer of recommendation

- quickstart

1. Tomcat Running on port 8082

## API end points

2. Get Recommendations of a user having emailid - mini@htrgmail.com

	<http://172.23.238.180:8082/api/v1/userrcm/mini@htrgmail.com>

3. Get all users

	<http://172.23.238.180:8082/api/v1/users>

