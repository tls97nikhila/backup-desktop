package com.stackroute.musixapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusixAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusixAppApplication.class, args);
	}

}
