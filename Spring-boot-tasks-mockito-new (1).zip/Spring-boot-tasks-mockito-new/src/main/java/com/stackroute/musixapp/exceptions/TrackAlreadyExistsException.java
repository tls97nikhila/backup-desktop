package com.stackroute.musixapp.exceptions;

public class TrackAlreadyExistsException  extends Exception{
    public TrackAlreadyExistsException(String message) {

        super(message);

    }
}
